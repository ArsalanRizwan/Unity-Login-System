<?php

include('db_config.php');

// Get admin input
$currentAdminId = $_POST['currentAdminId'];
$newAdminId = $_POST['newAdminId'];
$newAdminPassword = $_POST['newAdminPassword'];

// Validate input fields
if (empty($currentAdminId) || empty($newAdminId) || empty($newAdminPassword)) {
    echo json_encode(['error' => 'Please fill in all the fields']);
    exit();
}

// Check if the new Admin ID is 7 digits
if (strlen($newAdminId) !== 7) {
    echo json_encode(['error' => 'Invalid New Admin ID']);
    exit();
}

// Perform additional checks if required
// ...

//update the admin details

$updateQuery = "UPDATE admins SET admin_id = '$newAdminId', password = '$newAdminPassword' WHERE 
admin_id = '$currentAdminId'";
        if (mysqli_query($conn, $updateQuery)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Failed to update admin details']);
        }

// Close the database connection
mysqli_close($conn);
?>