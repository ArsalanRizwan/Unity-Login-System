<?php

include('db_config.php');

// Get the user ID from the request
$userId = $_POST['userId'];

// Check if the User ID is 7 digits
if (strlen($userId) !== 7) {
    echo json_encode(['error' => 'Invalid User ID']);
    exit();
}

// Perform additional checks if required
// ...

// Verify the User ID in the database
$query = "SELECT * FROM users WHERE unique_id = '$userId'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'User ID not found']);
}

// Close the database connection
mysqli_close($conn);
?>
