<?php

include('db_config.php');

// Get admin input
$currentAdminId = $_POST['currentAdminId'];
$currentAdminPassword = $_POST['currentAdminPassword'];

// Validate input fields
if (empty($currentAdminId) || empty($currentAdminPassword)) {
    echo json_encode(['error' => 'Please fill in all the fields']);
    exit();
}

// Check if the current Admin ID is 7 digits
if (strlen($currentAdminId) !== 7) {
    echo json_encode(['error' => 'Invalid Current Admin ID']);
    exit();
}

// Perform additional checks if required
// ...

// Check if the current admin details are correct
$query = "SELECT * FROM admins WHERE admin_id = '$currentAdminId'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if ($currentAdminPassword === $row['password']) {
        // Current admin details are correct
        echo json_encode(['success' => true]);
    } else {
        // Invalid password
        echo json_encode(['error' => 'Incorrect Admin Password']);
    }
} else {
    // Admin ID not found
    echo json_encode(['error' => 'Admin ID not found']);
}

// Close the database connection
mysqli_close($conn);
?>