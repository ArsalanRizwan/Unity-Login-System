<?php

include('db_config.php');

// Get user input
$name = $_POST['name'];
$email = $_POST['email'];
$userId = $_POST['userId'];
$password = $_POST['password'];

// Validate input fields
if (empty($name) || empty($email) || empty($userId) || empty($password)) {
    echo json_encode(['error' => 'Please fill in all the fields']);
    exit();
}

// Check if the User ID is 7 digits
if (strlen($userId) !== 7) {
    echo json_encode(['error' => 'Invalid User ID']);
    exit();
}

// Check if the User ID is already used
$query = "SELECT * FROM users WHERE unique_id = '$userId'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) {
    echo json_encode(['error' => 'User ID is already taken']);
    exit();
}

// Prepare and execute the SQL query to insert user details
$query = "INSERT INTO users (name, email, unique_id, password) VALUES ('$name', '$email', '$userId', '$password')";
if (mysqli_query($conn, $query)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'User registration failed']);
}

// Close the database connection
mysqli_close($conn);
?>
