<?php

include('db_config.php');

// Get user input
$userId = $_POST['userId'];
$password = $_POST['password'];

// Validate input fields
if (empty($userId) || empty($password)) {
    echo json_encode(['error' => 'Please enter the User ID and Password']);
    exit();
}

// Check if the User ID is 7 digits
if (strlen($userId) !== 7) {
    echo json_encode(['error' => 'Invalid User ID']);
    exit();
}

// Prepare and execute the SQL query to check user details
$query = "SELECT * FROM users WHERE unique_id = '$userId'";
$result = mysqli_query($conn, $query);

// Check if the user exists
if (mysqli_num_rows($result) > 0) {
    // User found, check password
    $user = mysqli_fetch_assoc($result);
    if ($password === $user['password']) {
        // Password matched, login successful
        // Get user data
        $name = $user['name'];
        $email = $user['email'];
        $uniqueId = $user['unique_id'];

        echo json_encode([
            'success' => true,
            'name' => $name,
            'email' => $email,
            'uniqueId' => $uniqueId
        ]);
    } else {
        // Incorrect password
        echo json_encode(['error' => 'Incorrect password']);
    }
} else {
    // User not found
    echo json_encode(['error' => 'User not found']);
}

// Close the database connection
mysqli_close($conn);
?>
