<?php

include('db_config.php');

// Get admin input
$adminId = $_POST['adminId'];
$adminPassword = $_POST['adminPassword'];

// Validate input fields
if (empty($adminId) || empty($adminPassword)) {
    echo json_encode(['error' => 'Please fill in all the fields']);
    exit();
}

// Check if the Admin ID is 7 digits
if (strlen($adminId) !== 7) {
    echo json_encode(['error' => 'Invalid Admin ID']);
    exit();
}

// Perform additional checks if required
// ...

// Compare admin login credentials against stored admin details
// Assuming you have an 'admin' table in your database with columns 'admin_id' and 'password'

$query = "SELECT * FROM admins WHERE admin_id = '$adminId'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    if ($adminPassword === $row['password']) {
        // Successful login
        echo json_encode(['success' => true]);
    } else {
        // Invalid password
        echo json_encode(['error' => 'Incorrect Admin Password']);
    }
} else {
    // Admin ID not found
    echo json_encode(['error' => 'Admin ID not found']);
}

// Close the database connection
mysqli_close($conn);
?>