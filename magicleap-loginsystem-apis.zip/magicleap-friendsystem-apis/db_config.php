<?php
// Database Configuration
$host = 'localhost'; // Change this to your MySQL server hostname
$username = 'id20900525_admin'; // Change this to your MySQL username
$password = '@A1b2c3d4'; // Change this to your MySQL password
$database = 'id20900525_login_system'; // Change this to the name of your MySQL database

// Create a database connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check if the connection was successful
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}
?>
