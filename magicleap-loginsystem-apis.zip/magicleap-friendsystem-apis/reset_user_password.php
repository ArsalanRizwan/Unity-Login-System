<?php

include('db_config.php');

// Get the user ID and new password from the request
$userId = $_POST['userId'];
$newPassword = $_POST['newPassword'];

// Check if the User ID is 7 digits
if (strlen($userId) !== 7) {
    echo json_encode(['error' => 'Invalid User ID']);
    exit();
}

// Perform additional checks if required
// ...

// Update the user's password in the database
$updateQuery = "UPDATE users SET password = '$newPassword' WHERE unique_id = '$userId'";

if (mysqli_query($conn, $updateQuery)) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'Failed to reset user password']);
}

// Close the database connection
mysqli_close($conn);
?>
